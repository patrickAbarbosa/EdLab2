#include <iostream>
#include <cstdlib>
#include "ListaSimplesOrd.h"

using namespace std;

ListaSimplesOrd::ListaSimplesOrd()
{
    primeiro = NULL;
}

ListaSimplesOrd::~ListaSimplesOrd()
{
    NoPonto *p = primeiro;
    while(p != NULL)
    {
        NoPonto *t = p->getProx();
        delete p;
        p = t;
    }
}

void ListaSimplesOrd::imprime()
{
    cout << "LISTA ORDENADA: ";
    if(primeiro == NULL)
    {
        cout << "Vazia!" << endl;
        return;
    }

    NoPonto *p = primeiro;
    while(p != NULL)
    {
        cout << "(" << p->getX() << ", " << p->getY() << "), ";
        p = p->getProx();
    }
    cout << endl;
}

// ----------------------------------------------------------------------------
//Q2
void ListaSimplesOrd::inserir(float x, float y)
{
    if(primeiro==NULL)
    {
        primeiro = new NoPonto();
        primeiro->setX(x);
        primeiro->setY(y);
    }
    else
    {
        NoPonto *p = primeiro;
        NoPonto *ant = NULL;
        while(p!=NULL)
        {
            if(p->getY()>y)
            {
                NoPonto *nPonto = new NoPonto();
                nPonto->setY(y);
                nPonto->setX(x);
                nPonto->setProx(p);
                if(p==primeiro)
                    primeiro = nPonto;
            }
            else
            {
                ant = p;
                p = p->getProx();
            }
        }
    }
}
//-Q2
// ----------------------------------------------------------------------------
