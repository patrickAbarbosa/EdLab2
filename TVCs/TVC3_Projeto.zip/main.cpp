// ############################################################################
// TVC 3 -- ESTRUTURA DE DADOS e LABORATORIO DE PROGRAMACAO II
// DATA: 27/11/2017
// PREENCHER ESTE CABECALHO COM SUAS INFORMACOES
// ALUNO:
// MATRICULA:
// ############################################################################
#include <iostream>
#include "ArvBinBusca.h"

using namespace std;

int main()
{
    cout << "TVC3 -- ESTRUTURA DE DADOS e LAB. DE PROG. II" << endl;
    cout << "FAVOR PREENCHER OS SEUS DADOS" << endl;
    cout << "Exemplo de ABB: " << endl;
    ArvBinBusca abb;
    //abb.insere(25); abb.insere(15); abb.insere(35);
    //abb.insere(3);  abb.insere(16); abb.insere(33);
    //abb.insere(45);

    abb.insere(40); abb.insere(15); abb.insere(10);
    abb.insere(20); abb.insere(19); abb.insere(35);
    abb.insere(75); abb.insere(50); abb.insere(45);
    abb.insere(60); abb.insere(80);

    abb.imprime();

    // TESTE DA QUESTAO 1 -----------------------------------------------------
    cout << endl << "TESTE DA QUESTAO 1" << endl;
    int nmaior = abb.nivelMaiorValor(60);
    cout << "Nivel maior valor: " << nmaior << endl;
    cout << endl;
    // ------------------------------------------------------------------------

    // TESTE DA QUESTAO 2 -----------------------------------------------------
    cout << endl << "TESTE DA QUESTAO 2" << endl;
    int dif = abb.difMaxMinFolha();
    cout << "Diferenca max-min: " << dif << endl;
    cout << endl;
    // ------------------------------------------------------------------------

    // TESTE DA QUESTAO 3 -----------------------------------------------------
    cout << endl << "TESTE DA QUESTAO 3" << endl;
    int ain = abb.alturaIntervalo(40,120);
    cout << "Altura intervalo: " << ain << endl;
    cout << endl;
    // ------------------------------------------------------------------------

    return 0;
}
