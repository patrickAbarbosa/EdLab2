#ifndef ARVBINBUSCA_H
#define ARVBINBUSCA_H
#include <iostream>
#include <cstdlib>
#include <math.h>
#include "No.h"

using namespace std;

class ArvBinBusca
{
public:
    ArvBinBusca();
    ~ArvBinBusca();
    void imprime();
    void insere(int x);
    bool vazia();

    // Questao 1  -------------------------------------------------------------
    int nivelMaiorValor(int ch);

    // Questao 2  -------------------------------------------------------------
    int difMaxMinFolha();

    // Questao 3  -------------------------------------------------------------
    int alturaIntervalo(int a, int b);

private:
    No *raiz;
    // funcoes auxiliares
    No *auxInsere(No *p, int x);
    void auxImprime(No *p, int nivel);
};

#endif //ARVBINBUSCA_H
