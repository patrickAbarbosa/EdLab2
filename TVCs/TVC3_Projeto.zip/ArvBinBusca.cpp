#include "ArvBinBusca.h"
#include <cmath>

// ----------------------------------------------------------------------------
//Q1
int ArvBinBusca::nivelMaiorValor(int ch)
{
  // Implemente aqui sua solucao
  return -1;
}
//-Q1
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//Q2
int ArvBinBusca::difMaxMinFolha()
{
  // Implemente aqui sua solucao
  return -1;
}
//-Q2
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
//Q3
int ArvBinBusca::alturaIntervalo(int a, int b)
{
  // Implemente aqui sua solucao
  return -1;
}
//-Q3
// ----------------------------------------------------------------------------


// ----------------------------------------------------------------------------
// Restante da classe ArvBinBusca
// ----------------------------------------------------------------------------

ArvBinBusca::ArvBinBusca()
{
    raiz = NULL;
}

ArvBinBusca::~ArvBinBusca()
{
    //n�o implementado!
}

bool ArvBinBusca::vazia()
{
    return raiz == NULL;
}

void ArvBinBusca::insere(int x)
{
    No *p = auxInsere(raiz, x);
    if(raiz == NULL)
        raiz = p;
}

No* ArvBinBusca::auxInsere(No *p, int x)
{
    if(p == NULL)
    {
        p = new No();
        p->setInfo(x);
        p->setEsq(NULL);
        p->setDir(NULL);
    }
    else if(x < p->getInfo())
        p->setEsq(auxInsere(p->getEsq(), x));
    else
        p->setDir(auxInsere(p->getDir(), x));
    return p;
}

void ArvBinBusca::imprime()
{
    auxImprime(raiz, 0);
}

void ArvBinBusca::auxImprime(No *p, int nivel)
{
    if(p != NULL)
    {
        cout << "(" << nivel << ")";
        for(int i = 1; i <= nivel; i++)
            cout << "--";
        cout << p->getInfo() << endl;
        auxImprime(p->getEsq(), nivel+1);
        auxImprime(p->getDir(), nivel+1);
    }
}
